#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void shifr(char *a,int *key,int L, FILE*fp);
void anshifr(char *a,int *key,int L,FILE*fp);
char s[27]="abcdefghijklmnopqrstuvwxyz";
void main()
{
	 FILE*fp;
	 char *a, s[15];
	 int *key, L=0, i=0;
	 printf("Enter the name of open file: ");
		 fp=fopen(gets(s), "r"); 
		 while(!feof(fp)) {getc(fp); L++;} 
		 a=(char*)malloc((L)*sizeof(char));
		 rewind(fp); L=0;
		 while(!feof(fp)) { a[L]=getc(fp); L++;}
		 a[L]='\0'; fclose(fp);
	 printf("Enter the key: ");
		 gets(s);
		 while(s[i]!='\0') i++;
		 key=(int*)malloc(i*sizeof(char)); i=0;
		 while(s[i]!='\0') {key[i]=s[i]-97; i++;}
	 printf("Enter the name of result file: ");
		fp=fopen(gets(s), "a+");
	 while(true)
	 {
		system("cls");
		printf("\nThe text: %s\n\n", a);
		printf("\n1.Shifrovanie texta.\n2.Deshifrovanie texta.\n3.Exit.\n\nYour choice: ");
		scanf("%d",&i);system("cls");
		switch(i)
			{
			 case 1:shifr(a,key,L,fp);
			 break;
			 case 2:anshifr(a,key,L,fp);
			 break;
			 default: fclose(fp);exit(1);
			}
	 }
}
void shifr(char *a,int *key, int L,FILE*fp)
{
	 int i,j,q=0;
	 for(i=0;i<L-1;i++)
	 {	
		if(a[i]!=' ')
	    {  
			for(j=0;j<26;j++)
				if(a[i]==s[j]) break;
		 a[i]=s[(key[q%6]+j)%26];
		 q++;
	    }
		else a[i]=' ';
	 }
	 printf("\nThe text: %s\n\n", a);
	 fprintf(fp, "%s\n", a);
}
void anshifr(char *a,int *key,int L,FILE*fp)
{
	int i,j,q=0;
	for(i=0;i<L-1;i++)
	{  
		if(a[i]!=' ')
		{ 
			for(j=0;j<26;j++)
				if(a[i]==s[j]) break;
		    if(j-key[q%6]<0) a[i]=s[j-key[q%6]+26];
		    else a[i]=s[j-key[q%6]];
		    q++;
		}
	    else a[i]=' ';
	 }
	 printf("\nThe text: %s\n\n", a);
	 fprintf(fp, "%s\n", a);
}
