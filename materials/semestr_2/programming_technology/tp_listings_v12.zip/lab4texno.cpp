#include <stdio.h>
#include <stdlib.h>
#define C 7
void main()
{
	FILE*fp=fopen("output.bin","wb");
	int a,b,m,kol, *X;
	printf("enter limits and number of figures:\n");scanf("%d %d %d", &a,&b,&kol);
	m=b-a;
	X=(int*)malloc(sizeof(int)*kol);
	X[0]=rand()%m+a; printf("%d ", X[0]);
	for(int i=0; i<kol-1; i++)
	{
		X[i+1]=(C*X[i])%m;
		if (X[i+1]<0) X[i+1]=X[i+1]+m;
		X[i+1]=X[i+1]+a;
		printf("%d ", X[i+1]);
	}
	for(int i=0; i<kol; i++)
		fwrite(X, sizeof(int), 1, fp);
	printf("\n");
	system("pause");
}

	
		

