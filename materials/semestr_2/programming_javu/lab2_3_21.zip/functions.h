struct data
{
	int rating;
	char lastName[256];
	data* next;
	data* prev;
};

struct info
{
	data* first;
	data* last;
};

data* addFromKeyborad();
void postCheck(int* choose, int from, int to);
void callAdd2ListMenu(int* choose);
void add2List(info* Info, data* newElem, bool autoMode);
void addFromTXT(char* name, info* Info);
void add2TXT(char* name, info* Info);
void addFromBin(char* name, info* Info);
void add2Bin(char* name, info* Info);
void cleanData(info* Info);
void callPrint2ScreenMenu(int* choose);
void printList2Screen(info* Info);
int callMenu();