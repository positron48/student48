#include <conio.h>
#include <locale.h>
#include "functions.h"

info Info;

void main()
{
	setlocale(LC_ALL, "Russian");
	while(true)
	{
		switch( callMenu() )
		{
		case 2: cleanData(&Info); break;
		case 4: return;
		case 5: addFromTXT("data.txt", &Info); break;
		case 6: addFromBin("data.bin", &Info); break;
		case 7: add2List(&Info, addFromKeyborad(), false); break;
		case 8: add2TXT("data.txt", &Info); break;
		case 9: add2Bin("data.bin", &Info); break;
		case 10: printList2Screen(&Info); break;
		}
	}
	getch();
}