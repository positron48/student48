﻿Public Class PeremCount
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text <> "" Then
            If IsNumeric(TextBox1.Text) Then
                If TextBox1.Text = Int(TextBox1.Text) And TextBox1.Text > 0 And TextBox1.Text < 14 Then
                    Me.Hide()
                    InputCoef.Show() 'Вызов формы ввода коэффициентов
                Else
                    MsgBox("Должно быть целое положительное число не больше 13!", MsgBoxStyle.Information)
                End If
            Else
                MsgBox("Введено нечисловое значение!", MsgBoxStyle.Information)
            End If
        Else
            MsgBox("Ничего не введено!", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub ВыходToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ВыходToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ОПрограммеToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ОПрограммеToolStripMenuItem.Click
        About.Show()
    End Sub

    Private Sub ВызовСправкиToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ВызовСправкиToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("Help.htm") Then
            If (Shell("explorer Help.htm", vbMaximizedFocus)) Then
            End If
        Else
            MsgBox("Файл справки не найден", MsgBoxStyle.Information)
        End If
    End Sub
End Class