﻿Public Class InputCoef
    Public N = PeremCount.TextBox1.Text       'Количество уравнений в системе
    Public inp2(N, N + 1) As TextBox                   'Массив полей ввода коэффициентов
    Public XLabels As Label                  'Надписи X1+, X2 + ... Xn =
    Public F_Width, F_Height As String           'Размеры окна
    Public Det, Det1_N(N) As Double
    Dim s As String

    Private Sub InputCoef_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        PeremCount.Close()
    End Sub

    Private Sub InputCoef_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i, j, RazX, RazY As Integer
        For i = 1 To N
            For j = 1 To N + 1
                inp2(i, j) = New TextBox                'Добавляемые поля ввода коэффициентов
        Next j, i

        RazX = 0                                'Коэффициент позиции по горизонтали
        RazY = 90                               'Коэффициент позиции по вертикали

        If N > 1 Then                           'Если одно уравнение в системе
            F_Width = 110 + 70 * N
            F_Height = 180 + 50 * N
        Else
            F_Width = 110 + 70 * 2
            F_Height = 120 + 50 * 2
            RazX = 40
        End If
        Me.Size = New Size(F_Width, F_Height)    'Установили размер окна
        Inp_Label.Location = New Point(F_Width / 2 - 120, 45) 'Определили положение главной надписи

        For i = 1 To N
            For j = 1 To N + 1
                XLabels = New Label         'Добавляем надписи X1+, X2 + ... Xn =
                If j Mod N = 0 Then
                    XLabels.Text = "X" & N & " ="              'Надписи Xn =
                Else
                    XLabels.Text = "X" & j Mod (N) & " +"     'Надписи X1+, X2 + ... Xn-1
                End If
                RazX = RazX + 70                              'Сдвинулись вправо

                inp2(i, j).Size = New Size(30, 20)
                inp2(i, j).Location = New Point(-40 + RazX, RazY) 'Определение положения полей ввода
                Me.Controls.Add(inp2(i, j))                         'Добавили поля ввода

                If j Mod (N + 1) <> 0 Then
                    XLabels.Size = New Size(35, 15)
                    XLabels.Location = New Point(-40 + RazX + 30, RazY + 3)
                    Me.Controls.Add(XLabels)
                End If
            Next j
            RazX = 0
            RazY = RazY + 50                 'Сместиться вниз
        Next i
        DetButton.Location = New Point(F_Width / 2 - 55, RazY)   'Определили положение кнопки "Решить систему"
    End Sub

    Function Determinant(FreeColum As Integer)
        Dim i, j, x, y, ti, tj, NN As Integer
        NN = Int(N)
        Dim Matrix(NN, NN), Deter, cc, tmp As Double
        Dim sign As Boolean
        For i = 1 To NN
            For j = 1 To NN
                If FreeColum = j Then
                    Matrix(i, j) = Val(inp2(i, NN + 1).Text)
                Else
                    Matrix(i, j) = Val(inp2(i, j).Text)      'Заполенине матрицы
                End If
        Next j, i
        sign = True
        Deter = 1                  'Детерминант

        If (NN = 2) Then
            Deter = Matrix(1, 1) * Matrix(2, 2) - Matrix(2, 1) * Matrix(1, 2) 'Если матрица 2х2
        Else
            For i = 1 To NN           'Проход по главной диагонали
                If Matrix(i, i) = 0 Then
                    x = 0
                    y = 0
                    For ti = i To NN
                        For tj = i To NN
                            If Matrix(ti, tj) <> 0 Then
                                x = ti
                                y = tj
                            End If
                    Next tj, ti
                    If x = 0 And y = 0 Then
                        Deter = 0
                        Return Deter
                    End If

                    If i <> y Then
                        For k = 1 To NN             'Меняем местами i-й и y-й столбцы
                            cc = Matrix(k, i)
                            Matrix(k, i) = Matrix(k, y)
                            Matrix(k, y) = cc
                        Next k
                        sign = Not (sign) 'Знак на противоположный
                    End If


                    If i <> x Then
                        For k = 1 To NN             'Меняем местами i-ую и x-ую строки
                            cc = Matrix(i, k)
                            Matrix(i, k) = Matrix(x, k)
                            Matrix(x, k) = cc
                        Next k
                        sign = Not (sign)    'Знак на противоположный
                    End If
                    i = i - 1               'Поменяли местами, а определитель не изменился, поэтому i--

                Else
                    Deter = Deter * Matrix(i, i)                'Выносим элемет Matrix(i,j) за определитель
                    tmp = Matrix(i, i)                      'Коэффициент для деления i-й строки
                    For x = i To NN
                        Matrix(i, x) = Matrix(i, x) / tmp           'Делим i-ю строку на коэффициент, получим Matrix(i,i)=1
                    Next x

                    For y = i + 1 To NN
                        tmp = Matrix(y, i)                     'Коэффицинт для приведения элементов под (i,i) к 0
                        For x = i To NN
                            Matrix(y, x) = Matrix(y, x) - Matrix(i, x) * tmp   'Вычитаем из всех строк ниже i-ой i-ю строку, умноженную на tmp
                    Next x, y
                End If
            Next i
        End If
        If sign = False Then Deter = -Deter
        Return Deter
    End Function

    Private Sub DetButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetButton.Click
        Dim i, j, k As Integer
        For i = 1 To N
            For j = 1 To N + 1
                If inp2(i, j).Text = "" Then
                    k = 1                  'Код ошибки
                    MsgBox("Остались незаполненные поля!", MsgBoxStyle.Information)
                    Exit Sub
                End If
                If IsNumeric(inp2(i, j).Text) = False Then
                    k = 2                   'Код ошибки
                    MsgBox("Введено нечисловое значение!", MsgBoxStyle.Information)
                    Exit Sub
                End If
        Next j, i

        Det = Determinant(0)
        If Det = 0 Then MsgBox("Главный определитель равен 0!" & Chr(13) & "Система не имеет единственного решения", MsgBoxStyle.Information)
        Rezult.Show()
        For i = 1 To N
            Det1_N(i) = Determinant(i)
            Rezult.Rez(i).Text = Det1_N(i) / Det
        Next
    End Sub

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        Me.Close()
    End Sub

    Private Sub ОПрограммеToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ОПрограммеToolStripMenuItem.Click
        About.Show()
    End Sub

    Private Sub ВызовСправкиToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ВызовСправкиToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("Help.htm") Then
            If (Shell("explorer Help.htm", vbMaximizedFocus)) Then
            End If
        Else
            MsgBox("Файл справки не найден", MsgBoxStyle.Information)
        End If
    End Sub
End Class