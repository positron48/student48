﻿Public Class Rezult
    Public N = PeremCount.TextBox1.Text          'Количество корней
    Public F_Width, F_Height As String           'Размеры окна
    Public Rez(N) As TextBox                   'Массив полей c результатом
    Public XLabels As Label                  'Надписи X1=, X2= + ... Xn=

    Private Sub Rezult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        F_Height = 135 + 40 * N                      'Высота окна
        Me.Size = New Size(225, F_Height)            'Новый размер окна
        Button1.Location = New Point(63, F_Height - 80)
        For i = 1 To N
            Rez(i) = New TextBox                'Добавляемые поля ввода коэффициентов
            XLabels = New Label         'Добавляем надписи X1=, X2= ... Xn=
            XLabels.Text = "X" & i & " ="
            XLabels.Location = New Point(15, 20 + i * 40)
            Rez(i).Size = New Size(110, 25)
            Rez(i).Location = New Point(55, 20 + i * 40) 'Определения положения полей ввода
            Me.Controls.Add(Rez(i))
            Me.Controls.Add(XLabels)
        Next i

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class