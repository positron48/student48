#include <stdio.h>
#include <conio.h>
#include "sin2deg.h"

int main()
{
	double sinus, degree1, degree2, degree3;
	printf ("Type some sinus of degree: ");
	scanf ("%lf", &sinus);
	if (sinus > 1.0 || sinus < -1.0 || sinus == 0.0)
	{
		printf ("Error, wrong data");
		_getch ();
		return 0;
	}
	degree1 = Sin2Deg (sinus);
	degree2 = 90.0-degree1;
	degree3 = 90.0;
	printf ("\r\nHere your degrees: \r\n1.%f \r\n2.%f \r\n3.%f \r\n", degree1, degree2, degree3);
	_getch ();
	return 0;
}