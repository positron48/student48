#include <math.h>

#define PI 3.1415926535

double Sin2Deg (double sinus)
{
	return asin(sinus)*180/PI;
}