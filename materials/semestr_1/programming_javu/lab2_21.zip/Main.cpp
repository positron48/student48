#include <conio.h>
#include "Computation.h"
int main()
{
	int const array_size = 10;
	double array_step = 3.6;
	double array_num[array_size];
	double multi_array = 1;

	Input(array_num, array_step, array_size);
	Multi(array_num, multi_array, array_size);
	ComputationY(array_num, array_size);

	_getch();

	return 0;
}