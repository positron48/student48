double Input(double array_num[], double array_step, int array_size);
int Multi(double array_num[], double multi_array, int array_size);
int ComputationY(double array_num[],int array_size);