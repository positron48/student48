#include <stdio.h>
#include <math.h>

double Input(double array_num[], double array_step, int array_size)
{
	printf("Type first element: ");
	scanf("%lf", &array_num[0]);

	for (int i = 1; i < array_size; i++)
	{
		array_num[i] = array_num[0] + array_step * i;

		printf("%f ", array_num[i]);
	}
	return array_num[array_size];
}
int Multi(double array_num[], double multi_array, int array_size)
{
	for (int i = 0; i < array_size; i++)
	{
		multi_array = array_num[i] * multi_array;
	}
	printf("\r\n\r\nMultiplication: ");
	printf("%e\r\n\r\n", multi_array);	
	return 0;
}
int ComputationY(double array_num[],int array_size)
{
	for (int i = 0; i < array_size; i++) 
	{
		if (array_num[i] < 0) 
		{
			array_num[i] = 5 * pow(array_num[i] , 2) + 3;
		}
		if (array_num[i] >= 0 && array_num[i] <= 20) 
		{
			if (array_num[i] == 1)
			{
				printf("y%i no value \r\n", i+1);
			}
			else
			{
			array_num[i] = (array_num[i] - 5) / (array_num[i] - 1);
			}
		}
		if (array_num[i] > 20) 
		{
			array_num[i] = array_num[i] / 6;
		}
		printf("y%i %.3f \r\n", i+1, array_num[i]);
	}
	return 0;
}