#include <conio.h>
#include "Func.h"

void main()
{
	double solution[29];
	float min_x = -8;
	float max_x = 20;
	computation(solution, min_x, max_x);
	_getch();
}