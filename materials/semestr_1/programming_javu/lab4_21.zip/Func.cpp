#include <stdio.h>

void computation(double solution[29], float min_x, float max_x)
{
	float min_y = 0;
	float max_y = 0;
	for (int i = min_x; i <= max_x; i++)
	{
		solution[i+8] = (i-1)*(i-5);
		if (solution[i+8] < min_y) min_y = solution[i+8];
		if (solution[i+8] > max_y) max_y = solution[i+8];
	}
	for (double j = 0; j < max_y - min_y; j = j + max_y/20)
	{
		for (int i = 0; i < 29; i++)
		{
			if (i == 0 && j == 0) printf("%.0f", max_y);
			if (i == 0 && j > max_y) printf("%.0f", min_y);
			if (i == 0) printf("\t");
			if ((solution[i] > ((max_y-max_y/20)-j)) && (solution[i] <= (max_y - j))) printf("*");
			else printf(" ");
			if (i == 28) printf("\n");
		}
	}
	printf("\t-8\t\t\t   20");
}