#include <conio.h>
#include <stdio.h>
#include "Funcs.h"

void main()
{
	char s[100], str[100]="", s1[100], s2[100];
	printf("String 1: ");
	  scanf("%s",&s1);
	printf("String 2: ");
	  scanf("%s",&s2);
	with_arr(s1,s2,s);
	with_str(s1,s2,str);
	_getch();
}