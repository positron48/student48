#include <stdio.h>
#include <string.h>

 void with_arr(char*s1,char*s2,char* s)
    {
            int n=0,m=1;
            for(int i=0;s1[i];i++)
                    for(int j=0;s2[j];j++)
                            if (s1[i]==s2[j])
                            {                              
                                    s[n]=s1[i];
                                    n++;
                            }
            s[n]=0;
            while (m!=0)
            {
            m=0;
            for (int i=0;s[i];i++)
                    for(int j=i+1;s[j];j++)
                            if(s[i]==s[j])
                            {
                                    m=m+1;
                                    for (int p=i;s[p];p++)
                                            s[p]=s[p+1];
                            }
            s[n-m]=0;
            }
            printf("With array: %s\n",s);
            return;
    }


void with_str(char*s1,char*s2,char* str)
{
    char a[1];
    char * pch;
    pch = strpbrk (s1, s2);
    while (pch != NULL)
		 {
			  a[0]=*pch;
			 if(strchr(str, a[0])==0)
	  			 strncat(str, pch, 1);
			 pch = strpbrk (pch+1,s2);
    }
    printf ("With string: %s\n" , str);
    return;
}