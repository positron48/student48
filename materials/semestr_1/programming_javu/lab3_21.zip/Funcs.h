void with_arr(char*s1,char*s2,char* s);
void with_str(char*s1,char*s2,char*str);